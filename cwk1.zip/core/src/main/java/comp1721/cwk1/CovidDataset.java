package comp1721.cwk1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CovidDataset {

  private LinkedList<CaseRecord> crList = new LinkedList<>();

  // TODO: Write stub for size()
  int size()
  {
    int num;
    num = crList.size();
    return num;
  }

  // TODO: Write stub for getRecord()

  CaseRecord getRecord(int index)
  {
    CaseRecord a;
    if (index < 0||index > crList.size()-1)
    {
      throw new DatasetException("Invalid input!");
    }
    a = crList.get(index);
    return a;
  }
  // TODO: Write stub for addRecord()
  void addRecord(CaseRecord rec)
  {
    crList.addLast(rec);
  }
  // TODO: Write stub for dailyCasesOn()

  CaseRecord dailyCasesOn(LocalDate date)
  {
    CaseRecord position = null;
    for (CaseRecord caseRecord : crList) {
      if (date == caseRecord.getDate()) {
        position = caseRecord;
        return position;
      }
    }
      if (position == null)
      {
        throw new DatasetException("No record is found!");
      }
    return position;
  }
  // TODO: Write stub for readDailyCases()

  void readDailyCases(String filename) throws IOException
  {
    crList.clear();
    BufferedReader reader = new BufferedReader(new FileReader(filename));
    reader.readLine();
    String temp = reader.readLine();
    while(temp != null)
    {
      /* Here I put all the data in an array, then pass to the CRlist */ 
      String[] data = temp.split(",");
      if (data.length != 4)
      {
        throw new DatasetException("Missing data!");
      }
      LocalDate d1 = LocalDate.parse(data[0]);
      int d2 = Integer.parseInt(data[1]);
      int d3 = Integer.parseInt(data[2]);
      int d4 = Integer.parseInt(data[3]);
      //add to CRlist
      addRecord(new CaseRecord(d1,d2,d3,d4));
      temp = reader.readLine();
    }
    reader.close();
  }
  // TODO: Write stub for writeActiveCases()
  void writeActiveCases(String filename) throws IOException
  {
    String title = "Date,Staff,Students,Other";
    File outFile = new File(filename);
    if(crList.size() < 10)
    {
      throw new DatasetException("Dataset is not long enough!");
    }
    BufferedWriter writer = new BufferedWriter(new FileWriter(outFile));
    writer.write(title);
    writer.newLine();
    String[] data;
    data = new String[20];
    for (int i = 9;i < crList.size();i++)
    {
      int tstfc = 0;
      int tstdc = 0;
      int totc = 0;
      for (int j = 0;j < 10;j++) {
        int stfc = crList.get(i - j).getStaffCases();
        tstfc += stfc;
        int stdc = crList.get(i - j).getStudentCases();
        tstdc += stdc;
        int otc = crList.get(i - j).getOtherCases();
        totc += otc;
      }
      LocalDate date = crList.get(i).getDate();
      DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      String dateStr = date.format(fmt);
      data[0] = dateStr + ",";
      data[1] = tstfc + ",";
      data[2] = tstdc + ",";
      data[3] = String.valueOf(totc);
      for (int j = 0; j<4; j++)
      {
        writer.write(data[j]);
      }
      writer.newLine();
    }
    writer.close();
  }
}
