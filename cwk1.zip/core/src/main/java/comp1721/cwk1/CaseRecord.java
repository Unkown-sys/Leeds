package comp1721.cwk1;

import java.time.LocalDate;

public class CaseRecord
{
  // TODO: Write stub for constructor
  private LocalDate date;
  private int staffCases;
  private int studentCases;
  private int otherCases;
  // TODO: Write stubs for four getter methods
  CaseRecord(LocalDate l_date, int i, int j, int k){
  if ( i < 0 || j < 0 || k < 0)
  {
    throw new DatasetException("Invalid input!");
  }
  date = l_date;
  staffCases = i;
  studentCases = j;
  otherCases = k;
  }
  LocalDate getDate ()
  {
    return this.date;
  }
  int getStaffCases ()
  {
    return this.staffCases;
  }
  int getStudentCases ()
  {
    return this.studentCases;
  }
  int getOtherCases ()
  {
    return this.otherCases;
  }
  // TODO: Write stub for totalCases()
  int totalCases ()
  {
    int totcases;
    totcases = this.staffCases + this.otherCases + this.studentCases;
    return totcases;
  }
  // TODO: Write stub for toString()
  public String toString()
  {
    String a = this.date + ": " + this.staffCases + " staff, " + this.studentCases + " students, ";
    return a + this.otherCases + " other";
  }
}
