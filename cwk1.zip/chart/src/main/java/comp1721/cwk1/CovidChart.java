package comp1721.cwk1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.io.IOException;

public class CovidChart extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        /* File name */
        String filename = "../datafiles/2020-daily.csv";
        //Create X axis
        NumberAxis xAxis = new NumberAxis(280, 350, 5);
        xAxis.setLabel("Day of Year");
        //Create Y axis
        NumberAxis yAxis = new NumberAxis   (0, 850, 50);
        yAxis.setLabel("Active Cases");
        //Create the line chart
        LineChart linechart = new LineChart(xAxis, yAxis);
        //Create the series
        XYChart.Series series = new XYChart.Series();
        series.setName("");
        //Read in all the data
        CovidDataset data = new CovidDataset();
        data.readDailyCases(filename);

        int day = 0;
        for (int i = 9; i < data.size(); i++)
        {
            int cases = 0;
            for (int j = 0; j < 10; j++)
            {
                cases += data.getRecord(i-j).totalCases();
                day = data.getRecord(i).getDate().getDayOfYear();
            }
            series.getData().add(new XYChart.Data(day, cases));
            linechart.getData().add(series);
        }
        //display
        Scene scene = new Scene(linechart, 1000, 600);

        stage.setTitle("Active Coronavirus Cases, University of Leeds");

        stage.setScene(scene);
        stage.show();
    }
    public static void main(String args[]){
        launch(args);
    }
}