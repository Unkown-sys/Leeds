package comp1721.cwk1;

import java.io.IOException;

public class ActiveCases {
  // Implement program for full solution here
  public static void main(String[] arg) throws IOException {
      if (arg.length != 2)
      {
        System.out.println("No args!");
        System.exit(0);
      }
      String inFile = arg[0];
      String outFile = arg[1];

      CovidDataset newList = new CovidDataset();
      newList.readDailyCases(inFile);
      newList.writeActiveCases(outFile);
      int cases = 0;
      for (int i = 0; i < newList.size();i++)
      {
        cases += newList.getRecord(i).totalCases();
      }
      System.out.println(cases);
  }
}
